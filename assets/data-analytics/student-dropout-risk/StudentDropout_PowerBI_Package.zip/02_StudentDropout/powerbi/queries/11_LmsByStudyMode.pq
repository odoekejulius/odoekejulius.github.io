let
    Source = Csv.Document(File.Contents(DataFolder & "lms_by_study_mode.csv"), [Delimiter = ",", Columns = 4, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    PromotedHeaders = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    ChangedTypes = Table.TransformColumnTypes(PromotedHeaders, {
        {"study_mode", type text},
        {"lms_band", type text},
        {"students", Int64.Type},
        {"dropout_rate", type number}
    }, "en-US")
in
    ChangedTypes
