let
    Source = Csv.Document(File.Contents(DataFolder & "adjusted_odds_ratios.csv"), [Delimiter = ",", Columns = 5, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    PromotedHeaders = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    ChangedTypes = Table.TransformColumnTypes(PromotedHeaders, {
        {"term", type text},
        {"OR", type number},
        {"lo", type number},
        {"hi", type number},
        {"p", type number}
    }, "en-US")
in
    ChangedTypes
