let
    Source = Csv.Document(File.Contents(DataFolder & "impact_scenarios.csv"), [Delimiter = ",", Columns = 4, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    PromotedHeaders = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    ChangedTypes = Table.TransformColumnTypes(PromotedHeaders, {
        {"retention_uplift_among_expected_dropouts", type number},
        {"students_in_scope", Int64.Type},
        {"expected_dropouts_in_scope", Int64.Type},
        {"students_retained", Int64.Type}
    }, "en-US")
in
    ChangedTypes
