let
    Source = Csv.Document(File.Contents(DataFolder & "risk_tier_summary.csv"), [Delimiter = ",", Columns = 7, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    PromotedHeaders = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    ChangedTypes = Table.TransformColumnTypes(PromotedHeaders, {
        {"risk_tier", type text},
        {"students", Int64.Type},
        {"dropouts", Int64.Type},
        {"mean_predicted", type number},
        {"actual_rate", type number},
        {"share_of_students", type number},
        {"share_of_all_dropouts", type number}
    }, "en-US")
in
    ChangedTypes
