let
    Source = Csv.Document(File.Contents(DataFolder & "model_comparison.csv"), [Delimiter = ",", Columns = 3, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    PromotedHeaders = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    ChangedTypes = Table.TransformColumnTypes(PromotedHeaders, {
        {"model", type text},
        {"auc_5fold", type number},
        {"description", type text}
    }, "en-US")
in
    ChangedTypes
