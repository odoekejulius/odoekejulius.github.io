"C:\PowerBI_Portfolio\StudentDropout\powerbi_data\" meta [IsParameterQuery = true, IsParameterQueryRequired = true, Type = "Text"]
