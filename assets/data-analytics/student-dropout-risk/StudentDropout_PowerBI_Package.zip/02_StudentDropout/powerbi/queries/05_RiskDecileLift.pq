let
    Source = Csv.Document(File.Contents(DataFolder & "risk_decile_lift.csv"), [Delimiter = ",", Columns = 7, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    PromotedHeaders = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    ChangedTypes = Table.TransformColumnTypes(PromotedHeaders, {
        {"risk_decile", Int64.Type},
        {"students", Int64.Type},
        {"dropouts", Int64.Type},
        {"mean_predicted", type number},
        {"actual_rate", type number},
        {"cum_dropouts_captured", type number},
        {"cum_students", type number}
    }, "en-US")
in
    ChangedTypes
