let
    Source = Csv.Document(File.Contents(DataFolder & "risk_flag_ladder.csv"), [Delimiter = ",", Columns = 4, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    PromotedHeaders = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    ChangedTypes = Table.TransformColumnTypes(PromotedHeaders, {
        {"risk_flag_count", Int64.Type},
        {"students", Int64.Type},
        {"dropouts", Int64.Type},
        {"dropout_rate", type number}
    }, "en-US")
in
    ChangedTypes
