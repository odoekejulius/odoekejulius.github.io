let
    Source = Csv.Document(File.Contents(DataFolder & "driver_ranking.csv"), [Delimiter = ",", Columns = 4, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    PromotedHeaders = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    ChangedTypes = Table.TransformColumnTypes(PromotedHeaders, {
        {"dimension", type text},
        {"min", type number},
        {"max", type number},
        {"spread_pp", type number}
    }, "en-US")
in
    ChangedTypes
