let
    Source = Csv.Document(File.Contents(DataFolder & "income_tuition_job_matrix.csv"), [Delimiter = ",", Columns = 6, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    PromotedHeaders = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    ChangedTypes = Table.TransformColumnTypes(PromotedHeaders, {
        {"family_income_level", type text},
        {"tuition_up_to_date", Int64.Type},
        {"part_time_job", Int64.Type},
        {"students", Int64.Type},
        {"dropouts", Int64.Type},
        {"dropout_rate", type number}
    }, "en-US")
in
    ChangedTypes
