let
    Source = Csv.Document(File.Contents(DataFolder & "fairness_audit.csv"), [Delimiter = ",", Columns = 9, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    PromotedHeaders = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    ChangedTypes = Table.TransformColumnTypes(PromotedHeaders, {
        {"attribute", type text},
        {"group", type text},
        {"students", Int64.Type},
        {"actual_dropout_rate", type number},
        {"mean_predicted_risk", type number},
        {"flagged_rate", type number},
        {"true_positive_rate", type number},
        {"false_positive_rate", type number},
        {"auc", type number}
    }, "en-US")
in
    ChangedTypes
