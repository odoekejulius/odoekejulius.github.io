let
    Source = Csv.Document(File.Contents(DataFolder & "segment_dropout_rates.csv"), [Delimiter = ",", Columns = 10, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    PromotedHeaders = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    ChangedTypes = Table.TransformColumnTypes(PromotedHeaders, {
        {"dimension", type text},
        {"value", type text},
        {"students", Int64.Type},
        {"dropouts", Int64.Type},
        {"dropout_rate", type number},
        {"ci_low", type number},
        {"ci_high", type number},
        {"lift_vs_overall", type number},
        {"value_order", Int64.Type},
        {"value_key", type text}
    }, "en-US")
in
    ChangedTypes
