let
    Source = Csv.Document(File.Contents(DataFolder & "risk_flag_definitions.csv"), [Delimiter = ",", Columns = 6, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    PromotedHeaders = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    ChangedTypes = Table.TransformColumnTypes(PromotedHeaders, {
        {"flag", type text},
        {"students_flagged", Int64.Type},
        {"share_flagged", type number},
        {"dropout_rate_flagged", type number},
        {"dropout_rate_not_flagged", type number},
        {"gap_pp", type number}
    }, "en-US")
in
    ChangedTypes
