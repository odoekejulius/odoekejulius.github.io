let
    Source = Csv.Document(File.Contents(DataFolder & "matches_clean.csv"), [Delimiter = ",", Columns = 16, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    PromotedHeaders = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    ChangedTypes = Table.TransformColumnTypes(PromotedHeaders, {
        {"match_id", Int64.Type},
        {"match_date", type date},
        {"stage", type text},
        {"group", type text},
        {"team_1", type text},
        {"team_2", type text},
        {"score_1", Int64.Type},
        {"score_2", Int64.Type},
        {"winner", type text},
        {"decided_by_penalties", type logical},
        {"notes", type text},
        {"is_draw", type logical},
        {"total_goals", Int64.Type},
        {"goal_margin", Int64.Type},
        {"is_knockout", type logical},
        {"stage_order", Int64.Type}
    }, "en-US")
in
    ChangedTypes
