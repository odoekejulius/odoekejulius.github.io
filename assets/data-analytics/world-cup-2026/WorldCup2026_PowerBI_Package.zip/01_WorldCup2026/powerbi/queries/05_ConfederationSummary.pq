let
    Source = Csv.Document(File.Contents(DataFolder & "confederation_summary.csv"), [Delimiter = ",", Columns = 13, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    PromotedHeaders = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    ChangedTypes = Table.TransformColumnTypes(PromotedHeaders, {
        {"confederation", type text},
        {"teams_entered", Int64.Type},
        {"matches_played", Int64.Type},
        {"wins", Int64.Type},
        {"draws", Int64.Type},
        {"losses", Int64.Type},
        {"goals_for", Int64.Type},
        {"goals_against", Int64.Type},
        {"win_pct", type number},
        {"goals_per_match", type number},
        {"reached_round_of_32", Int64.Type},
        {"reached_round_of_16", Int64.Type},
        {"still_active", Int64.Type}
    }, "en-US")
in
    ChangedTypes
