let
    Source = Csv.Document(File.Contents(DataFolder & "data_cleaning_log.csv"), [Delimiter = ",", Columns = 4, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    PromotedHeaders = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    ChangedTypes = Table.TransformColumnTypes(PromotedHeaders, {
        {"team", type text},
        {"old_eliminated_round", type text},
        {"corrected_eliminated_round", type text},
        {"reason", type text}
    }, "en-US")
in
    ChangedTypes
