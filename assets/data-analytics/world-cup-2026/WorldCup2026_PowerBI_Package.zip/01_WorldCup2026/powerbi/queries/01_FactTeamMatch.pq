let
    Source = Csv.Document(File.Contents(DataFolder & "fact_team_match.csv"), [Delimiter = ",", Columns = 20, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    PromotedHeaders = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    ChangedTypes = Table.TransformColumnTypes(PromotedHeaders, {
        {"match_id", Int64.Type},
        {"match_date", type date},
        {"stage", type text},
        {"stage_order", Int64.Type},
        {"group", type text},
        {"is_knockout", type logical},
        {"team", type text},
        {"opponent", type text},
        {"goals_for", Int64.Type},
        {"goals_against", Int64.Type},
        {"decided_by_penalties", type logical},
        {"winner", type text},
        {"notes", type text},
        {"result", type text},
        {"goal_diff", Int64.Type},
        {"points", Int64.Type},
        {"clean_sheet", type logical},
        {"confederation", type text},
        {"host_nation", type logical},
        {"world_cup_debut", type logical}
    }, "en-US")
in
    ChangedTypes
