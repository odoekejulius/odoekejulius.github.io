let
    Source = Csv.Document(File.Contents(DataFolder & "dim_team_summary.csv"), [Delimiter = ",", Columns = 16, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    PromotedHeaders = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    ChangedTypes = Table.TransformColumnTypes(PromotedHeaders, {
        {"team", type text},
        {"group", type text},
        {"confederation", type text},
        {"host_nation", type logical},
        {"world_cup_debut", type logical},
        {"eliminated_round", type text},
        {"still_active", type logical},
        {"matches_played", Int64.Type},
        {"wins", Int64.Type},
        {"draws", Int64.Type},
        {"losses", Int64.Type},
        {"goals_for", Int64.Type},
        {"goals_against", Int64.Type},
        {"clean_sheets", Int64.Type},
        {"goal_diff", Int64.Type},
        {"points", Int64.Type}
    }, "en-US")
in
    ChangedTypes
