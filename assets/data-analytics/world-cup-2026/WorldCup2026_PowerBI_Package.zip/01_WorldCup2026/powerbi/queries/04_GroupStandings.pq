let
    Source = Csv.Document(File.Contents(DataFolder & "group_standings.csv"), [Delimiter = ",", Columns = 12, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    PromotedHeaders = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    ChangedTypes = Table.TransformColumnTypes(PromotedHeaders, {
        {"group", type text},
        {"team", type text},
        {"played", Int64.Type},
        {"won", Int64.Type},
        {"drawn", Int64.Type},
        {"lost", Int64.Type},
        {"goals_for", Int64.Type},
        {"goals_against", Int64.Type},
        {"goal_diff", Int64.Type},
        {"points", Int64.Type},
        {"group_rank", Int64.Type},
        {"confederation", type text}
    }, "en-US")
in
    ChangedTypes
