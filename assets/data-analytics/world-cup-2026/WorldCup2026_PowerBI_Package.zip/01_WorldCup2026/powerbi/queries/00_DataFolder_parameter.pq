"C:\PowerBI_Portfolio\WorldCup2026\powerbi_data\" meta [IsParameterQuery = true, IsParameterQueryRequired = true, Type = "Text"]
