let
    Source = Csv.Document(File.Contents(DataFolder & "gpa_decomposition.csv"), [Delimiter = ",", Columns = 5, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    PromotedHeaders = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    ChangedTypes = Table.TransformColumnTypes(PromotedHeaders, {
        {"model", type text},
        {"n", Int64.Type},
        {"usage_coefficient", type number},
        {"r_squared", type number},
        {"share_of_usage_effect_remaining", type number}
    }, "en-US")
in
    ChangedTypes
