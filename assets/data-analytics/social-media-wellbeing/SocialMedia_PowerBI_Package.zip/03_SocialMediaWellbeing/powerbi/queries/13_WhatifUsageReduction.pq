let
    Source = Csv.Document(File.Contents(DataFolder & "whatif_usage_reduction.csv"), [Delimiter = ",", Columns = 4, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    PromotedHeaders = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    ChangedTypes = Table.TransformColumnTypes(PromotedHeaders, {
        {"hours_reduced_per_day", type number},
        {"mental_health_points_gained", type number},
        {"gpa_points_gained", type number},
        {"sleep_hours_gained", type number}
    }, "en-US")
in
    ChangedTypes
