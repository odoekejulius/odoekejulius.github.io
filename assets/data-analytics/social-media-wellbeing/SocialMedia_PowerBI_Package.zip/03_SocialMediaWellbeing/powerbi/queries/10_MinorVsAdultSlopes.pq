let
    Source = Csv.Document(File.Contents(DataFolder & "minor_vs_adult_slopes.csv"), [Delimiter = ",", Columns = 4, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    PromotedHeaders = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    ChangedTypes = Table.TransformColumnTypes(PromotedHeaders, {
        {"outcome", type text},
        {"slope_adults", type number},
        {"slope_minors", type number},
        {"difference_p_value", type number}
    }, "en-US")
in
    ChangedTypes
