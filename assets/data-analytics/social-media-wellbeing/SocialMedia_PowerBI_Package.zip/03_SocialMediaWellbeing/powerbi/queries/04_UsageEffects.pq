let
    Source = Csv.Document(File.Contents(DataFolder & "usage_effects.csv"), [Delimiter = ",", Columns = 10, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    PromotedHeaders = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    ChangedTypes = Table.TransformColumnTypes(PromotedHeaders, {
        {"outcome", type text},
        {"n", Int64.Type},
        {"slope_per_extra_hour", type number},
        {"ci_low", type number},
        {"ci_high", type number},
        {"r_squared", type number},
        {"adjusted_slope", type number},
        {"adj_ci_low", type number},
        {"adj_ci_high", type number},
        {"adjusted_r_squared", type number}
    }, "en-US")
in
    ChangedTypes
