let
    Source = Csv.Document(File.Contents(DataFolder & "correlations.csv"), [Delimiter = ",", Columns = 3, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    PromotedHeaders = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    ChangedTypes = Table.TransformColumnTypes(PromotedHeaders, {
        {"variable_x", type text},
        {"variable_y", type text},
        {"correlation", type number}
    }, "en-US")
in
    ChangedTypes
