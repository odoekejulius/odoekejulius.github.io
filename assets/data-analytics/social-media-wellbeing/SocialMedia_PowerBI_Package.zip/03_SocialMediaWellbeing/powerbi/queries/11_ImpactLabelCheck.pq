let
    Source = Csv.Document(File.Contents(DataFolder & "impact_label_check.csv"), [Delimiter = ",", Columns = 3, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    PromotedHeaders = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    ChangedTypes = Table.TransformColumnTypes(PromotedHeaders, {
        {"predictors", type text},
        {"tree_depth", Int64.Type},
        {"accuracy", type number}
    }, "en-US")
in
    ChangedTypes
