let
    Source = Csv.Document(File.Contents(DataFolder & "platform_comparison.csv"), [Delimiter = ",", Columns = 10, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    PromotedHeaders = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    ChangedTypes = Table.TransformColumnTypes(PromotedHeaders, {
        {"platform", type text},
        {"students", Int64.Type},
        {"mean_usage", type number},
        {"mean_mh", type number},
        {"mean_gpa", type number},
        {"mean_stress", type number},
        {"adj_mh_diff_vs_instagram", type number},
        {"adj_ci_low", type number},
        {"adj_ci_high", type number},
        {"adj_p_value", type number}
    }, "en-US")
in
    ChangedTypes
