let
    Source = Csv.Document(File.Contents(DataFolder & "late_night_by_tier.csv"), [Delimiter = ",", Columns = 5, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    PromotedHeaders = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    ChangedTypes = Table.TransformColumnTypes(PromotedHeaders, {
        {"usage_tier", type text},
        {"students", Int64.Type},
        {"mean_mh", type number},
        {"mean_sleep", type number},
        {"late_night", type text}
    }, "en-US")
in
    ChangedTypes
