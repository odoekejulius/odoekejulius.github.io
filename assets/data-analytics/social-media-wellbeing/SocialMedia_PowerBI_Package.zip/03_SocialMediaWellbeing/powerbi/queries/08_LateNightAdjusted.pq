let
    Source = Csv.Document(File.Contents(DataFolder & "late_night_adjusted.csv"), [Delimiter = ",", Columns = 5, Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    PromotedHeaders = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    ChangedTypes = Table.TransformColumnTypes(PromotedHeaders, {
        {"outcome", type text},
        {"late_night_coefficient_controlling_usage", type number},
        {"ci_low", type number},
        {"ci_high", type number},
        {"p_value", type number}
    }, "en-US")
in
    ChangedTypes
