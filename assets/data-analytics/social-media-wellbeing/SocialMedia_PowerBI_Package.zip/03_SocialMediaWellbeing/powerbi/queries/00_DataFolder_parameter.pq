"C:\PowerBI_Portfolio\SocialMedia\powerbi_data\" meta [IsParameterQuery = true, IsParameterQueryRequired = true, Type = "Text"]
